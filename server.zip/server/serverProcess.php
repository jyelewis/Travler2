<?php
$access = 'server';
require('../SysData/init.php');
require('functions.php');
$userTied->allowSave = false;
$stopTime = time() + 15;
sendLog('Server process spawned');

while(true)
{
	updateTime();
	//start server loop
	if($updateFiles = $fs->hasFileUpdates())
	//if(false)
	{
		foreach($updateFiles as $file)
		{
			$file = $db->query("SELECT * FROM files WHERE fileID = ':1'", $file['fileID']);
			$file = $file[0];
			sendLog('Analysing file "'.basename($file['path']).'"');

			$filename = $siteLocalRoot.'/file/data/'.$file['userID'].$file['path'];
			$metadata = $getID3->analyze($filename);
			getid3_lib::CopyTagsToComments($metadata);
			$mime = (isset($metadata['mime_type']))? $metadata['mime_type'] : 'text/plain';
			$fs->updateMetaData($file['path'], serialize($metadata), $mime);
			
			//unlink($filename);
			sendLog('Updated metadata for file "'.basename($file['path']).'"');
			updateTime();
		}
	}

	//end server loop
	usleep(50000);
	if (time() >= $stopTime){ break; }
}
sendLog('Server process dying');
function updateTime()
{
	global $db;
	$result = $db->query("SELECT value FROM serverPrams WHERE title='lastLoop'");
	if ($result[0]['value'] != time())
	{
		$db->writeQuery("UPDATE serverPrams SET value = ':1' WHERE title='lastLoop'", time());
	}
}
echo 'safequit';
?>